/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puntodeventas;

import javax.swing.*;
import java.awt.*;
/**
 *
 * @author ivone
 */
public class InformacionContacto extends JFrame  {
public InformacionContacto() {
        setTitle("Información de Contacto");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

       
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(255, 228, 236));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        
        JLabel titulo = new JLabel("Información de Contacto", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 20));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setForeground(new Color(128, 0, 64));
        panel.add(titulo);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        panel.add(crearCampoConIcono("Dirección", "📍", "CARR A SAN PEDRO IXTLAHUACA KM 3 COL COL LA CAÑADA 71222,OAX"));
        panel.add(crearCampoConIcono("Teléfono", "📞", "951 456 59 63 / 274 142 94 82"));
        panel.add(crearCampoConIcono("Correo", "✉️",  "novaeleganciaquefluye@gmail.com"));
        panel.add(crearCampoConIcono("Redes ", "📱", "Instagram: NOVAELEGANCIA, Facebook: NOVAE ELEGANCIA Q_F"));
        panel.add(crearCampoConIcono("Horario", "🕒", "Lunes a Sábado: 9 am a 9 pm / Domingo: 9 am a 5 pm"));

        
        JButton btnCerrar = new JButton("CERRAR");
        btnCerrar.setBackground(new Color(240, 128, 128));
        btnCerrar.setForeground(Color.WHITE);
        btnCerrar.setFocusPainted(false);
        btnCerrar.setFont(new Font("Arial", Font.BOLD, 14));
        btnCerrar.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCerrar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnCerrar.addActionListener(e -> dispose());
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnCerrar);

        add(panel);
    }

    private JPanel crearCampoConIcono(String texto, String icono, String contenido) {
        JPanel panelCampo = new JPanel();
        panelCampo.setLayout(new BorderLayout());
        panelCampo.setBackground(new Color(255, 228, 236));

        JLabel etiquetaIcono = new JLabel(icono);
        etiquetaIcono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24)); // Tamaño aumentado a 24
        etiquetaIcono.setPreferredSize(new Dimension(50, 40)); // Espacio aumentado
        panelCampo.add(etiquetaIcono, BorderLayout.WEST);

        JTextField campoTexto = new JTextField(contenido);
        campoTexto.setFont(new Font("Arial", Font.PLAIN, 14));
        campoTexto.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.PINK));
        campoTexto.setEditable(false);
        panelCampo.add(campoTexto, BorderLayout.CENTER);

        JLabel etiquetaTexto = new JLabel(texto);
        etiquetaTexto.setFont(new Font("Arial", Font.PLAIN, 14));
        etiquetaTexto.setForeground(new Color(128, 0, 64));
        panelCampo.add(etiquetaTexto, BorderLayout.NORTH);

        panelCampo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        return panelCampo;
    }

    public static void main(String[] args) {
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            InformacionContacto ventana = new InformacionContacto();
            ventana.setVisible(true);
        });
    }
}
