/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puntodeventas;

/**
 *
 * @author minparis.gomez
 */

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class Correo {
  public static void enviarCorreo(String destinatario, String asunto, String mensajeTexto) throws Exception {
        final String remitente = "gomezlizette360@gmail.com"; 
        final String contrasena = "minPar1s19";   

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session sesion = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, contrasena);
            }
        });

        Message mensaje = new MimeMessage(sesion);
        mensaje.setFrom(new InternetAddress(remitente));
        mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        mensaje.setSubject(asunto);
        mensaje.setText(mensajeTexto);

        Transport.send(mensaje);
    }
}  
