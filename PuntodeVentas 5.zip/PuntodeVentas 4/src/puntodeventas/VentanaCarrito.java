package puntodeventas;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class VentanaCarrito extends JFrame {

    private JTable tablaProductos, tablaCarrito;
    private JButton btnAgregar, btnFinalizar, btnCerrar;
    private JLabel lblTotal;
    private DefaultTableModel modeloProductos, modeloCarrito;
    private JTextField txtBusqueda;

    private int idCliente = 1;
    private int idEmpleado = 1;
    private String metodoPago = "Efectivo";

    public VentanaCarrito() {
        setTitle("Carrito de Compras");
        setSize(1000, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        cargarProductos("");
    }

    private void initComponents() {
        Color rosaClaro = Color.decode("#FADADD");
        Color rosaEncabezado = Color.decode("#F8BBD0");

        setLayout(new BorderLayout());

        JPanel panelBusqueda = new JPanel(new BorderLayout());
        panelBusqueda.setBackground(rosaClaro);

        txtBusqueda = new JTextField();
        JButton btnBuscar = new JButton(new ImageIcon("lupa.png"));
        btnBuscar.setPreferredSize(new Dimension(30, 30));
        panelBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        panelBusqueda.add(btnBuscar, BorderLayout.EAST);

        txtBusqueda.addActionListener(e -> cargarProductos(txtBusqueda.getText().trim()));
        btnBuscar.addActionListener(e -> cargarProductos(txtBusqueda.getText().trim()));

        modeloProductos = new DefaultTableModel(new String[]{"ID", "Nombre", "Precio", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaProductos = new JTable(modeloProductos);
        tablaProductos.getTableHeader().setBackground(rosaEncabezado);
        tablaProductos.getTableHeader().setForeground(Color.BLACK);
        JScrollPane scroll1 = new JScrollPane(tablaProductos);

        modeloCarrito = new DefaultTableModel(new String[]{"ID", "Nombre", "Cantidad", "Precio", "Subtotal"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaCarrito = new JTable(modeloCarrito);
        tablaCarrito.getTableHeader().setBackground(rosaEncabezado);
        tablaCarrito.getTableHeader().setForeground(Color.BLACK);
        JScrollPane scroll2 = new JScrollPane(tablaCarrito);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotones.setBackground(rosaClaro);

        btnAgregar = new JButton("Agregar al Carrito");
        btnFinalizar = new JButton("Finalizar Compra");
        btnCerrar = new JButton("Cerrar");

        lblTotal = new JLabel("Total: $0.00");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 16));
        lblTotal.setForeground(Color.BLACK);

        panelBotones.add(btnAgregar);
        panelBotones.add(btnFinalizar);
        panelBotones.add(btnCerrar);
        panelBotones.add(lblTotal);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(rosaClaro);
        panelPrincipal.add(panelBusqueda, BorderLayout.NORTH);
        panelPrincipal.add(scroll1, BorderLayout.CENTER);

        add(panelPrincipal, BorderLayout.NORTH);
        add(scroll2, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        getContentPane().setBackground(rosaClaro);

        btnAgregar.addActionListener(e -> agregarAlCarrito());
        btnFinalizar.addActionListener(e -> finalizarCompra());
        btnCerrar.addActionListener(e -> dispose());
    }

    private void cargarProductos(String busqueda) {
        modeloProductos.setRowCount(0);
        try (Connection con = ConexionSQLite.conectar()) {
            String sql = "SELECT id_producto, nombre_producto, precio, stock FROM productos WHERE stock > 0";
            if (!busqueda.isEmpty()) {
                sql += " AND nombre_producto LIKE ?";
            }

            PreparedStatement pst = con.prepareStatement(sql);
            if (!busqueda.isEmpty()) {
                pst.setString(1, "%" + busqueda + "%");
            }

            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                modeloProductos.addRow(new Object[]{
                    rs.getInt("id_producto"),
                    rs.getString("nombre_producto"),
                    rs.getDouble("precio"),
                    rs.getInt("stock")
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + ex.getMessage());
        }
    }

    private void agregarAlCarrito() {
        int fila = tablaProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto");
            return;
        }

        int id = (int) modeloProductos.getValueAt(fila, 0);
        String nombre = (String) modeloProductos.getValueAt(fila, 1);
        double precio = (double) modeloProductos.getValueAt(fila, 2);
        int stock = (int) modeloProductos.getValueAt(fila, 3);

        String input = JOptionPane.showInputDialog(this, "Cantidad:");
        if (input == null) return;

        int cantidad;
        try {
            cantidad = Integer.parseInt(input);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Cantidad inválida");
            return;
        }

        if (cantidad <= 0 || cantidad > stock) {
            JOptionPane.showMessageDialog(this, "Cantidad fuera de rango");
            return;
        }

        boolean encontrado = false;
        for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
            if ((int) modeloCarrito.getValueAt(i, 0) == id) {
                int nuevaCantidad = (int) modeloCarrito.getValueAt(i, 2) + cantidad;
                modeloCarrito.setValueAt(nuevaCantidad, i, 2);
                modeloCarrito.setValueAt(precio * nuevaCantidad, i, 4);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            double subtotal = precio * cantidad;
            modeloCarrito.addRow(new Object[]{id, nombre, cantidad, precio, subtotal});
        }

        actualizarTotal();
    }

    private void actualizarTotal() {
        double total = 0;
        for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
            total += (double) modeloCarrito.getValueAt(i, 4);
        }
        lblTotal.setText(String.format("Total: $%.2f", total));
    }

    private void finalizarCompra() {
        if (modeloCarrito.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "El carrito está vacío.");
            return;
        }

        try (Connection con = ConexionSQLite.conectar()) {
            con.setAutoCommit(false);

            double totalVenta = 0;
            for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
                totalVenta += (double) modeloCarrito.getValueAt(i, 4);
            }

            String sqlVenta = "INSERT INTO ventas (id_cliente, total, metodo_pago, id_empleado) VALUES (?, ?, ?, ?)";
            PreparedStatement pstVenta = con.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);
            pstVenta.setInt(1, idCliente);
            pstVenta.setDouble(2, totalVenta);
            pstVenta.setString(3, metodoPago);
            pstVenta.setInt(4, idEmpleado);
            pstVenta.executeUpdate();

            ResultSet rs = pstVenta.getGeneratedKeys();
            int idVenta = -1;
            if (rs.next()) {
                idVenta = rs.getInt(1);
            }

            if (idVenta == -1) {
                con.rollback();
                throw new SQLException("No se pudo generar ID de la venta.");
            }

            String sqlDetalle = "INSERT INTO detalles_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
            String sqlStock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
            PreparedStatement pstDetalle = con.prepareStatement(sqlDetalle);
            PreparedStatement pstStock = con.prepareStatement(sqlStock);

            for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
                int idProducto = (int) modeloCarrito.getValueAt(i, 0);
                int cantidad = (int) modeloCarrito.getValueAt(i, 2);
                double precioUnitario = (double) modeloCarrito.getValueAt(i, 3);

                pstDetalle.setInt(1, idVenta);
                pstDetalle.setInt(2, idProducto);
                pstDetalle.setInt(3, cantidad);
                pstDetalle.setDouble(4, precioUnitario);
                pstDetalle.executeUpdate();

                pstStock.setInt(1, cantidad);
                pstStock.setInt(2, idProducto);
                pstStock.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(this, "¡Compra finalizada y registrada con éxito!");
            modeloCarrito.setRowCount(0);
            actualizarTotal();
            cargarProductos(txtBusqueda.getText().trim());

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al finalizar compra: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VentanaCarrito().setVisible(true);
        });
    }
}