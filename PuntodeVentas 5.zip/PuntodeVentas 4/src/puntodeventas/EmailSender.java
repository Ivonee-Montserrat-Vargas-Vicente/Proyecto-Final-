package puntodeventas;

import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailSender {
    private static final String SMTP_HOST = "smtp.gmail.com"; // Cambia según tu proveedor
    private static final String SMTP_PORT = "587";
    private static final String EMAIL_FROM = "novaeleganciaquefluye@gmail.com"; // Tu correo de envío
    private static final String EMAIL_PASSWORD = "jkis kqcg tgik baqj"; // Contraseña de aplicación

    public static void enviarCredenciales(String emailDestino, String nombreArchivoPDF) {
        // Configuración de propiedades
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);

        // Crear sesión
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
            }
        });

        try {
            // Crear mensaje
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailDestino));
            message.setSubject("Tus Credenciales de Registro - Punto de Ventas NOVAE");

            // Cuerpo del mensaje
            MimeBodyPart texto = new MimeBodyPart();
            texto.setText("Estimado usuario,\n\n"
                    + "Adjunto encontrará sus credenciales de acceso al sistema.\n"
                    + "Por seguridad, le recomendamos cambiar su contraseña después del primer acceso.\n\n"
                    + "Atentamente,\n"
                    + "El equipo de Punto de Ventas NOVAE");

            // Adjuntar PDF
            MimeBodyPart adjunto = new MimeBodyPart();
            DataSource source = new FileDataSource(nombreArchivoPDF);
            adjunto.setDataHandler(new DataHandler(source));
            adjunto.setFileName("Credenciales_Acceso.pdf");

            // Ensamblar mensaje
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(texto);
            multipart.addBodyPart(adjunto);

            message.setContent(multipart);

            // Enviar correo
            Transport.send(message);

            System.out.println("Correo enviado exitosamente a: " + emailDestino);
        } catch (MessagingException e) {
            System.err.println("Error al enviar correo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}