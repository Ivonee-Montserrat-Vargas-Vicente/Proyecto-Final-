package puntodeventas;

import java.sql.*;
import java.time.LocalDate;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class RegistrarProducto extends JFrame {
    private JTextField txtNombre, txtDescripcion, txtTalla, txtColor;
    private JTextField txtPrecio, txtStock;
    private JButton btnRegistrar, btnCancelar;
    private JComboBox<String> cmbEstado;
    private JComboBox<String> cmbCategoria;
    private JComboBox<String> cmbProveedor;

    public RegistrarProducto() {
        setTitle("Registrar Producto");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.decode("#FADADD")); 

        panel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panel.add(txtNombre);
        
        panel.add(new JLabel("Descripción:"));
        txtDescripcion = new JTextField();
        panel.add(txtDescripcion);
        
        panel.add(new JLabel("Categoría:"));
        cmbCategoria = new JComboBox<>();
        cargarCategorias();
        panel.add(cmbCategoria);
        
        panel.add(new JLabel("Talla:"));
        txtTalla = new JTextField();
        panel.add(txtTalla);
        
        panel.add(new JLabel("Color:"));
        txtColor = new JTextField();
        panel.add(txtColor);
        
        panel.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panel.add(txtPrecio);
        
        panel.add(new JLabel("Stock:"));
        txtStock = new JTextField();
        panel.add(txtStock);
        
        panel.add(new JLabel("Proveedor:"));
        cmbProveedor = new JComboBox<>();
        cargarProveedores();
        panel.add(cmbProveedor);
        
        panel.add(new JLabel("Estado:"));
        cmbEstado = new JComboBox<>(new String[]{"Activo", "Inactivo"});
        panel.add(cmbEstado);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setBackground(Color.decode("#FADADD")); // También rosa claro
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.addActionListener(this::registrarProducto);
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());
        
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnCancelar);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.decode("#FADADD"));
        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarCategorias() {
        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "SELECT nombre FROM categorias";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                cmbCategoria.addItem(rs.getString("nombre"));
            }

            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar categorías: " + e.getMessage());
        }
    }

    private void cargarProveedores() {
        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "SELECT id_proveedor, nombre_empresa FROM proveedores";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id_proveedor");
                String nombre = rs.getString("nombre_empresa");
                cmbProveedor.addItem(id + " - " + nombre);
            }

            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar proveedores: " + e.getMessage());
        }
    }

    private void registrarProducto(ActionEvent evt) {
        if(txtNombre.getText().isEmpty() || 
           cmbCategoria.getSelectedItem() == null || 
           txtTalla.getText().isEmpty() || 
           txtColor.getText().isEmpty() ||
           txtPrecio.getText().isEmpty() || 
           txtStock.getText().isEmpty() ||
           cmbProveedor.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos obligatorios", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "INSERT INTO productos (nombre_producto, descripcion, categoria, talla, color, "
                       + "precio, stock, fecha_ingreso, estado, id_proveedor) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, txtNombre.getText());
            pst.setString(2, txtDescripcion.getText());
            pst.setString(3, cmbCategoria.getSelectedItem().toString());
            pst.setString(4, txtTalla.getText());
            pst.setString(5, txtColor.getText());
            pst.setDouble(6, Double.parseDouble(txtPrecio.getText()));
            pst.setInt(7, Integer.parseInt(txtStock.getText()));
            pst.setString(8, LocalDate.now().toString());
            pst.setString(9, cmbEstado.getSelectedItem().toString());

            String seleccionado = cmbProveedor.getSelectedItem().toString();
            int idProveedor = Integer.parseInt(seleccionado.split(" - ")[0]);
            pst.setInt(10, idProveedor);
            
            int resultado = pst.executeUpdate();
            
            if(resultado > 0) {
                JOptionPane.showMessageDialog(this, "Producto registrado con éxito");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo registrar el producto");
            }

            con.close();
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error en formato de números: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error de base de datos: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtDescripcion.setText("");
        cmbCategoria.setSelectedIndex(0);
        txtTalla.setText("");
        txtColor.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        cmbProveedor.setSelectedIndex(0);
        cmbEstado.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegistrarProducto frame = new RegistrarProducto();
            frame.setVisible(true);
        });
    }
}