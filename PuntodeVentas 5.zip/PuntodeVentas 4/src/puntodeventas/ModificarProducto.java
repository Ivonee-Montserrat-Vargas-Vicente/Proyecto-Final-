package puntodeventas;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ModificarProducto extends JFrame {
    private JTextField txtIdBuscar, txtNombre, txtDescripcion, txtTalla, txtColor;
    private JTextField txtPrecio, txtStock;
    private JButton btnBuscar, btnModificar, btnCancelar;
    private JComboBox<String> cmbEstado;
    private JComboBox<String> cmbCategoria;
    private JComboBox<String> cmbProveedor;

    public ModificarProducto() {
        setTitle("Modificar Producto");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.decode("#FADADD"));

        panel.add(new JLabel("ID Producto a modificar:"));
        txtIdBuscar = new JTextField();
        panel.add(txtIdBuscar);

        btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(this::buscarProducto);
        panel.add(btnBuscar);
        panel.add(new JLabel()); // espacio vacío para alinear

        panel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panel.add(txtNombre);

        panel.add(new JLabel("Descripción:"));
        txtDescripcion = new JTextField();
        panel.add(txtDescripcion);

        panel.add(new JLabel("Categoría:"));
        cmbCategoria = new JComboBox<>();
        cargarCategorias();
        panel.add(cmbCategoria);

        panel.add(new JLabel("Talla:"));
        txtTalla = new JTextField();
        panel.add(txtTalla);

        panel.add(new JLabel("Color:"));
        txtColor = new JTextField();
        panel.add(txtColor);

        panel.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panel.add(txtPrecio);

        panel.add(new JLabel("Stock:"));
        txtStock = new JTextField();
        panel.add(txtStock);

        panel.add(new JLabel("Proveedor:"));
        cmbProveedor = new JComboBox<>();
        cargarProveedores();
        panel.add(cmbProveedor);

        panel.add(new JLabel("Estado:"));
        cmbEstado = new JComboBox<>(new String[]{"Activo", "Inactivo"});
        panel.add(cmbEstado);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setBackground(Color.decode("#FADADD"));

        btnModificar = new JButton("Modificar");
        btnModificar.addActionListener(this::modificarProducto);
        btnModificar.setEnabled(false);
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());

        panelBotones.add(btnModificar);
        panelBotones.add(btnCancelar);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.decode("#FADADD"));
        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarCategorias() {
        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "SELECT nombre FROM categorias";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            cmbCategoria.removeAllItems();
            while (rs.next()) {
                cmbCategoria.addItem(rs.getString("nombre"));
            }
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar categorías: " + e.getMessage());
        }
    }

    private void cargarProveedores() {
        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "SELECT id_proveedor, nombre_empresa FROM proveedores";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            cmbProveedor.removeAllItems();
            while (rs.next()) {
                int id = rs.getInt("id_proveedor");
                String nombre = rs.getString("nombre_empresa");
                cmbProveedor.addItem(id + " - " + nombre);
            }
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar proveedores: " + e.getMessage());
        }
    }

    private void buscarProducto(ActionEvent evt) {
        if (txtIdBuscar.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un ID de producto", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "SELECT * FROM productos WHERE id_producto = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(txtIdBuscar.getText()));

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtNombre.setText(rs.getString("nombre_producto"));
                txtDescripcion.setText(rs.getString("descripcion"));

                String cat = rs.getString("categoria");
                if (cat != null) {
                    cmbCategoria.setSelectedItem(cat);
                } else {
                    cmbCategoria.setSelectedIndex(0);
                }

                txtTalla.setText(rs.getString("talla"));
                txtColor.setText(rs.getString("color"));
                txtPrecio.setText(String.valueOf(rs.getDouble("precio")));
                txtStock.setText(String.valueOf(rs.getInt("stock")));

                int idProv = rs.getInt("id_proveedor");
                if (rs.wasNull()) {
                    cmbProveedor.setSelectedIndex(0);
                } else {
                    for (int i = 0; i < cmbProveedor.getItemCount(); i++) {
                        String item = cmbProveedor.getItemAt(i);
                        int idEnCombo = Integer.parseInt(item.split(" - ")[0]);
                        if (idEnCombo == idProv) {
                            cmbProveedor.setSelectedIndex(i);
                            break;
                        }
                    }
                }

                String estado = rs.getString("estado");
                if (estado != null) {
                    cmbEstado.setSelectedItem(estado);
                } else {
                    cmbEstado.setSelectedIndex(0);
                }

                btnModificar.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un producto con ese ID",
                        "Error", JOptionPane.ERROR_MESSAGE);
                limpiarCampos();
                btnModificar.setEnabled(false);
            }
            con.close();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El ID debe ser un número válido",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error en la base de datos: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modificarProducto(ActionEvent evt) {
        if (txtNombre.getText().isEmpty() ||
            cmbCategoria.getSelectedItem() == null ||
            txtTalla.getText().isEmpty() ||
            txtColor.getText().isEmpty() ||
            txtPrecio.getText().isEmpty() ||
            txtStock.getText().isEmpty() ||
            cmbProveedor.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos obligatorios",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de modificar este producto?", "Confirmar",
            JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "UPDATE productos SET nombre_producto = ?, descripcion = ?, categoria = ?, "
                       + "talla = ?, color = ?, precio = ?, stock = ?, estado = ?, id_proveedor = ? "
                       + "WHERE id_producto = ?";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, txtNombre.getText());
            pst.setString(2, txtDescripcion.getText());
            pst.setString(3, cmbCategoria.getSelectedItem().toString());
            pst.setString(4, txtTalla.getText());
            pst.setString(5, txtColor.getText());
            pst.setDouble(6, Double.parseDouble(txtPrecio.getText()));
            pst.setInt(7, Integer.parseInt(txtStock.getText()));
            pst.setString(8, cmbEstado.getSelectedItem().toString());

            String provSeleccionado = cmbProveedor.getSelectedItem().toString();
            int idProveedor = Integer.parseInt(provSeleccionado.split(" - ")[0]);
            pst.setInt(9, idProveedor);

            pst.setInt(10, Integer.parseInt(txtIdBuscar.getText()));

            int resultado = pst.executeUpdate();

            if (resultado > 0) {
                JOptionPane.showMessageDialog(this, "Producto modificado con éxito");
                limpiarCampos();
                btnModificar.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo modificar el producto");
            }

            con.close();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error en formato de números: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error en la base de datos: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        txtIdBuscar.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");
        if (cmbCategoria.getItemCount() > 0) cmbCategoria.setSelectedIndex(0);
        txtTalla.setText("");
        txtColor.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        if (cmbProveedor.getItemCount() > 0) cmbProveedor.setSelectedIndex(0);
        if (cmbEstado.getItemCount() > 0) cmbEstado.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ModificarProducto frame = new ModificarProducto();
            frame.setVisible(true);
        });
    }
}