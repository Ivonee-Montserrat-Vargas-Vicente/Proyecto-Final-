package puntodeventas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

public class HistorialVentas extends JInternalFrame {
private JTable tablaVentas;
    private DefaultTableModel modeloTabla;
    private JLabel lblEstado;

    public HistorialVentas() {
        setTitle("Historial de Ventas");
        setSize(900, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        cargarHistorial();
    }

    private void initComponents() {
        Color rosaClaro = Color.decode("#FADADD");
        Color rosaEncabezado = Color.decode("#F8BBD0"); // tono más fuerte

        modeloTabla = new DefaultTableModel(new String[]{
            "ID Venta", "ID Cliente", "Fecha", "Total", "Método de Pago", "Estado", "ID Empleado"
        }, 0);

        tablaVentas = new JTable(modeloTabla) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                if (!isRowSelected(row)) {
                    c.setBackground(rosaClaro);
                    c.setForeground(Color.BLACK);
                } else {
                    c.setBackground(new Color(255, 192, 203)); // rosa más intenso al seleccionar
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        };

        // Encabezado personalizado
        JTableHeader header = tablaVentas.getTableHeader();
        header.setBackground(rosaEncabezado);
        header.setForeground(Color.BLACK);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));

        JScrollPane scroll = new JScrollPane(tablaVentas);

        lblEstado = new JLabel("Cargando ventas...");
        lblEstado.setOpaque(true);
        lblEstado.setBackground(rosaClaro);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(rosaClaro);
        panelPrincipal.add(scroll, BorderLayout.CENTER);
        panelPrincipal.add(lblEstado, BorderLayout.SOUTH);

        getContentPane().add(panelPrincipal);
        getContentPane().setBackground(rosaClaro);
    }

    private void cargarHistorial() {
        try (Connection con = ConexionSQLite.conectar()) {
            String sql = "SELECT * FROM ventas ORDER BY fecha_venta DESC";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            int contador = 0;
            while (rs.next()) {
                modeloTabla.addRow(new Object[]{
                    rs.getInt("id_venta"),
                    rs.getInt("id_cliente"),
                    rs.getString("fecha_venta"),
                    String.format("$%.2f", rs.getDouble("total")),
                    rs.getString("metodo_pago"),
                    rs.getString("estado_pedido"),
                    rs.getObject("id_empleado")
                });
                contador++;
            }

            lblEstado.setText("Total de ventas registradas: " + contador);

        } catch (SQLException ex) {
            ex.printStackTrace();
            lblEstado.setText("Error al cargar historial de ventas: " + ex.getMessage());
            lblEstado.setForeground(Color.RED);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new HistorialVentas().setVisible(true);
        });
    }
}