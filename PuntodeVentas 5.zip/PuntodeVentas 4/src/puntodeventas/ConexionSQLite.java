

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package puntodeventas;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSQLite {
private static final String url = "jdbc:sqlite:C:/Users/ivone/OneDrive/Escritorio/Estructura de datos/PuntodeVentas 4/PuntodeVentas 2/NOVAE.db";

    public static Connection conectar() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(url);
            System.out.println("✅ Conexión exitosa a SQLite.");
        } catch (SQLException e) {
            System.out.println("❌ Error de conexión:");
            e.printStackTrace(); // Esto mostrará el error real
        }
        return conexion;
    }

    public static void main(String[] args) {
        conectar();
    }
}
