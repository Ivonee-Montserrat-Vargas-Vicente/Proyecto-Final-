package puntodeventas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.*;

public class prueba extends JFrame {

    private JTextField txtNombre, txtApellido, txtUsuario;
    private JPasswordField txtContrasena, txtConfirmar;
    private JComboBox<String> comboTipoUsuario;
    private JButton btnRegistrar, btnRegresar;

    public prueba() {
        setTitle("Registro de Usuario");
        setSize(470, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        setLayout(null);

        JLabel lblTitulo = new JLabel("Registrar Usuario");
        lblTitulo.setBounds(150, 20, 200, 30);
        add(lblTitulo);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(40, 70, 100, 20);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(160, 70, 200, 25);
        add(txtNombre);

        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(40, 110, 100, 20);
        add(lblApellido);

        txtApellido = new JTextField();
        txtApellido.setBounds(160, 110, 200, 25);
        add(txtApellido);

        JLabel lblUsuario = new JLabel("Usuario (Correo):");
        lblUsuario.setBounds(40, 150, 120, 20);
        add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(160, 150, 200, 25);
        add(txtUsuario);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setBounds(40, 190, 100, 20);
        add(lblContrasena);

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(160, 190, 200, 25);
        add(txtContrasena);

        JLabel lblConfirmar = new JLabel("Confirmar contraseña:");
        lblConfirmar.setBounds(40, 230, 150, 20);
        add(lblConfirmar);

        txtConfirmar = new JPasswordField();
        txtConfirmar.setBounds(160, 230, 200, 25);
        add(txtConfirmar);

        JLabel lblTipo = new JLabel("Tipo de usuario:");
        lblTipo.setBounds(40, 270, 120, 20);
        add(lblTipo);

        comboTipoUsuario = new JComboBox<>(new String[]{"Administrador", "Cajero"});
        comboTipoUsuario.setBounds(160, 270, 200, 25);
        add(comboTipoUsuario);

        btnRegistrar = new JButton("Registrar Usuario");
        btnRegistrar.setBounds(160, 320, 150, 30);
        add(btnRegistrar);

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(160, 360, 150, 30);
        add(btnRegresar);

        btnRegistrar.addActionListener(e -> registrarUsuario());
        btnRegresar.addActionListener(e -> {
            new Loginn().setVisible(true);
            dispose();
        });
    }

    private void registrarUsuario() {
        String nombre = txtNombre.getText().trim();
        String apellido = txtApellido.getText().trim();
        String usuario = txtUsuario.getText().trim();
        String contrasena = new String(txtContrasena.getPassword());
        String confirmacion = new String(txtConfirmar.getPassword());
        String tipoUsuario = comboTipoUsuario.getSelectedItem().toString();

        if (!validarEmail(usuario)) {
            JOptionPane.showMessageDialog(this, "Ingrese un correo electrónico válido.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!contrasena.equals(confirmacion)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection con = ConexionSQLite.conectar();
            String sql = "INSERT INTO usuarios (nombre, usuario, contrasena, tipo_usuario) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, nombre + " " + apellido);
            pst.setString(2, usuario);
            pst.setString(3, contrasena);
            pst.setString(4, tipoUsuario);

            int resultado = pst.executeUpdate();

            if (resultado > 0) {
                String archivoPDF = GeneraPDF.generarPDFRegistro(nombre, apellido, usuario, contrasena, tipoUsuario);
                
                EmailSender.enviarCredenciales(usuario, archivoPDF);

                JOptionPane.showMessageDialog(this,
                        "Registro exitoso.\nSe enviaron tus credenciales al correo: " + usuario,
                        "Registro Completado", JOptionPane.INFORMATION_MESSAGE);

                limpiarCampos();
                this.dispose();
            }
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error de base de datos: " + ex.getMessage());
        }
    }

    private boolean validarEmail(String email) {
        return email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtUsuario.setText("");
        txtContrasena.setText("");
        txtConfirmar.setText("");
        comboTipoUsuario.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new prueba().setVisible(true);
        });
    }
}
