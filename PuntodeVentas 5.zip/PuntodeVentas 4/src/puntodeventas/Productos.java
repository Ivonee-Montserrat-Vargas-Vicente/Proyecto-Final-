/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package puntodeventas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author minparis.gomez
 */
public class Productos extends javax.swing.JFrame {
    
    private JTextField txtNombre, txtPrecio, txtTalla, txtCantidad;
    private JTable tabla;
    private DefaultTableModel modelo;
        

    /**
     * Creates new form Productos
     */
    public Productos() {
        initComponents();
        setTitle("Gestión de Productos - Tienda de Ropa");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre:");
        JLabel lblPrecio = new JLabel("Precio:");
        JLabel lblTalla = new JLabel("Talla:");
        JLabel lblCantidad = new JLabel("Cantidad:");

        txtNombre = new JTextField();
        txtPrecio = new JTextField();
        txtTalla = new JTextField();
        txtCantidad = new JTextField();

        lblNombre.setBounds(10, 10, 80, 25);
        txtNombre.setBounds(90, 10, 120, 25);
        lblPrecio.setBounds(230, 10, 80, 25);
        txtPrecio.setBounds(290, 10, 100, 25);
        lblTalla.setBounds(10, 45, 80, 25);
        txtTalla.setBounds(90, 45, 120, 25);
        lblCantidad.setBounds(230, 45, 80, 25);
        txtCantidad.setBounds(290, 45, 100, 25);

        add(lblNombre); add(txtNombre);
        add(lblPrecio); add(txtPrecio);
        add(lblTalla); add(txtTalla);
        add(lblCantidad); add(txtCantidad);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");

        btnAgregar.setBounds(420, 10, 120, 25);
        btnEditar.setBounds(420, 45, 120, 25);
        btnEliminar.setBounds(420, 80, 120, 25);

        add(btnAgregar); add(btnEditar); add(btnEliminar);

        modelo = new DefaultTableModel(new String[]{"Nombre", "Precio", "Talla", "Cantidad"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(10, 120, 560, 200);

        add(scroll);

        // Acciones
        btnAgregar.addActionListener(e -> agregarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnEditar.addActionListener(e -> editarProducto());

        tabla.getSelectionModel().addListSelectionListener(e -> cargarDatos());
    }

    private void agregarProducto() {
        String nombre = txtNombre.getText();
        String precio = txtPrecio.getText();
        String talla = txtTalla.getText();
        String cantidad = txtCantidad.getText();

        if (!nombre.isEmpty() && !precio.isEmpty() && !talla.isEmpty() && !cantidad.isEmpty()) {
            modelo.addRow(new Object[]{nombre, precio, talla, cantidad});
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos.");
        }
    }

    private void eliminarProducto() {
        int fila = tabla.getSelectedRow();
        if (fila != -1) {
            modelo.removeRow(fila);
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar.");
        }
    }

    private void editarProducto() {
        int fila = tabla.getSelectedRow();
        if (fila != -1) {
            modelo.setValueAt(txtNombre.getText(), fila, 0);
            modelo.setValueAt(txtPrecio.getText(), fila, 1);
            modelo.setValueAt(txtTalla.getText(), fila, 2);
            modelo.setValueAt(txtCantidad.getText(), fila, 3);
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para editar.");
        }
    }

    private void cargarDatos() {
        int fila = tabla.getSelectedRow();
        if (fila != -1) {
            txtNombre.setText((String) modelo.getValueAt(fila, 0));
            txtPrecio.setText((String) modelo.getValueAt(fila, 1));
            txtTalla.setText((String) modelo.getValueAt(fila, 2));
            txtCantidad.setText((String) modelo.getValueAt(fila, 3));
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtTalla.setText("");
        txtCantidad.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Productos().setVisible(true));
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
   
       

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
