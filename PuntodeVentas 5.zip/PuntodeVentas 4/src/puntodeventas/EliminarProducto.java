package puntodeventas;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EliminarProducto extends JFrame {
    private JTextField txtId;
    private JTextArea txtDatos;
    private JButton btnBuscar, btnEliminar, btnCancelar;
    private JLabel lblEstado;

    public EliminarProducto() {
        setTitle("Eliminar Producto");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        Color rosaClaro = Color.decode("#FADADD");
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(rosaClaro);

        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBusqueda.setBackground(rosaClaro);
        panelBusqueda.add(new JLabel("ID Producto:"));
        txtId = new JTextField(10);
        panelBusqueda.add(txtId);
        btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(this::buscarProducto);
        panelBusqueda.add(btnBuscar);

        // Área de datos
        txtDatos = new JTextArea(8, 30);
        txtDatos.setEditable(false);
        txtDatos.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(txtDatos);

        // Panel de estado
        lblEstado = new JLabel(" ");
        lblEstado.setForeground(Color.RED);
        lblEstado.setOpaque(true);
        lblEstado.setBackground(rosaClaro);

        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setBackground(rosaClaro);
        btnEliminar = new JButton("Eliminar");
        btnEliminar.addActionListener(this::eliminarProducto);
        btnEliminar.setEnabled(false);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());

        panelBotones.add(btnEliminar);
        panelBotones.add(btnCancelar);

        panel.add(panelBusqueda, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(lblEstado, BorderLayout.SOUTH);
        panel.add(panelBotones, BorderLayout.PAGE_END);

        getContentPane().add(panel);
        getContentPane().setBackground(rosaClaro); // Fondo general
    }

    private void buscarProducto(ActionEvent evt) {
        String idText = txtId.getText().trim();
        if (idText.isEmpty()) {
            mostrarError("Ingrese un ID de producto");
            return;
        }

        try {
            int idProducto = Integer.parseInt(idText);
            Connection con = ConexionSQLite.conectar();

            String sql = "SELECT * FROM productos WHERE id_producto = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, idProducto);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                mostrarDatosProducto(rs);
                btnEliminar.setEnabled(true);
                lblEstado.setText("Producto encontrado. Verifique los datos antes de eliminar.");
                lblEstado.setForeground(Color.BLUE);
            } else {
                mostrarError("No existe producto con ID: " + idProducto);
                btnEliminar.setEnabled(false);
            }

            con.close();
        } catch (NumberFormatException e) {
            mostrarError("El ID debe ser un número entero");
        } catch (SQLException ex) {
            mostrarError("Error de BD: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void mostrarDatosProducto(ResultSet rs) throws SQLException {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(rs.getInt("id_producto")).append("\n");
        sb.append("Nombre: ").append(rs.getString("nombre_producto")).append("\n");
        sb.append("Categoría: ").append(rs.getString("categoria")).append("\n");
        sb.append("Precio: $").append(rs.getDouble("precio")).append("\n");
        sb.append("Stock: ").append(rs.getInt("stock")).append("\n");
        sb.append("Estado: ").append(rs.getString("estado")).append("\n");
        txtDatos.setText(sb.toString());
    }

    private void eliminarProducto(ActionEvent evt) {
        int idProducto = Integer.parseInt(txtId.getText().trim());
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Eliminar permanentemente este producto?\nID: " + idProducto,
            "Confirmar Eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            Connection con = ConexionSQLite.conectar();
            con.setAutoCommit(false);

            String verificarSql = "SELECT 1 FROM productos WHERE id_producto = ?";
            PreparedStatement verificarPst = con.prepareStatement(verificarSql);
            verificarPst.setInt(1, idProducto);
            ResultSet rs = verificarPst.executeQuery();

            if (!rs.next()) {
                mostrarError("El producto ya no existe en la BD");
                return;
            }

            String eliminarSql = "DELETE FROM productos WHERE id_producto = ?";
            PreparedStatement eliminarPst = con.prepareStatement(eliminarSql);
            eliminarPst.setInt(1, idProducto);

            int filasAfectadas = eliminarPst.executeUpdate();
            con.commit();

            if (filasAfectadas > 0) {
                JOptionPane.showMessageDialog(this,
                    "Producto eliminado correctamente\nFilas afectadas: " + filasAfectadas,
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
                txtId.setText("");
                txtDatos.setText("");
                btnEliminar.setEnabled(false);
                lblEstado.setText("Eliminación exitosa. Filas afectadas: " + filasAfectadas);
                lblEstado.setForeground(new Color(0, 100, 0));
            } else {
                mostrarError("No se eliminó ningún registro. ¿El ID es correcto?");
            }

            con.close();
        } catch (SQLException ex) {
            mostrarError("Error al eliminar: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void mostrarError(String mensaje) {
        lblEstado.setText(mensaje);
        lblEstado.setForeground(Color.RED);
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EliminarProducto frame = new EliminarProducto();
            frame.setVisible(true);
        });
    }
}