package puntodeventas;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VisualizarProductos extends JFrame {
    private JTable tablaProductos;
    private JScrollPane scrollPane;
    private JButton btnActualizar, btnCerrar;
    private JComboBox<String> cmbFiltro;
    private JTextField txtBusqueda;
    private JLabel lblEstado;

    public VisualizarProductos() {
        setTitle("Listado de Productos");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        cargarProductos();  // Cargar productos al iniciar
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        Color rosaClaro = Color.decode("#FADADD");

        // Panel superior de búsqueda y filtro
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSuperior.setBackground(rosaClaro);

        cmbFiltro = new JComboBox<>(new String[]{"Todos", "Activos", "Inactivos", "Por nombre", "Por categoría"});
        txtBusqueda = new JTextField(20);
        btnActualizar = new JButton("Actualizar");
        btnCerrar = new JButton("Cerrar");

        panelSuperior.add(new JLabel("Filtro:"));
        panelSuperior.add(cmbFiltro);
        panelSuperior.add(new JLabel("Buscar:"));
        panelSuperior.add(txtBusqueda);
        panelSuperior.add(btnActualizar);
        panelSuperior.add(btnCerrar);

        add(panelSuperior, BorderLayout.NORTH);

        // Tabla de productos
        tablaProductos = new JTable();
        scrollPane = new JScrollPane(tablaProductos);
        scrollPane.getViewport().setBackground(rosaClaro);
        add(scrollPane, BorderLayout.CENTER);

        // Etiqueta de estado
        lblEstado = new JLabel(" ");
        lblEstado.setBackground(rosaClaro);
        lblEstado.setOpaque(true);
        add(lblEstado, BorderLayout.SOUTH);

        // Fondo general
        getContentPane().setBackground(rosaClaro);

        // Eventos
        btnActualizar.addActionListener(e -> cargarProductos());
        btnCerrar.addActionListener(e -> dispose());
    }

    private void cargarProductos() {
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
            "ID", "Nombre", "Descripción", "Categoría", "Talla",
            "Color", "Precio", "Stock", "Estado", "ID Proveedor"
        });

        try {
            Connection con = ConexionSQLite.conectar();
            StringBuilder sql = new StringBuilder("SELECT p.* FROM productos p WHERE 1=1 ");

            // Aplicar filtros
            String filtro = cmbFiltro.getSelectedItem().toString();
            String busqueda = txtBusqueda.getText().trim();

            if (filtro.equals("Activos")) {
                sql.append("AND p.estado = 'Activo' ");
            } else if (filtro.equals("Inactivos")) {
                sql.append("AND p.estado = 'Inactivo' ");
            } else if (filtro.equals("Por nombre") && !busqueda.isEmpty()) {
                sql.append("AND p.nombre_producto LIKE ? ");
            } else if (filtro.equals("Por categoría") && !busqueda.isEmpty()) {
                sql.append("AND p.categoria LIKE ? ");
            }

            sql.append("ORDER BY p.nombre_producto");

            PreparedStatement pst = con.prepareStatement(sql.toString());

            // Si hay parámetros para el LIKE
            if ((filtro.equals("Por nombre") || filtro.equals("Por categoría")) && !busqueda.isEmpty()) {
                pst.setString(1, "%" + busqueda + "%");
            }

            ResultSet rs = pst.executeQuery();

            int contador = 0;
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id_producto"),
                    rs.getString("nombre_producto"),
                    rs.getString("descripcion"),
                    rs.getString("categoria"),
                    rs.getString("talla"),
                    rs.getString("color"),
                    String.format("$%.2f", rs.getDouble("precio")),
                    rs.getInt("stock"),
                    rs.getString("estado"),
                    rs.getObject("id_proveedor")
                });
                contador++;
            }

            tablaProductos.setModel(model);
            lblEstado.setText("Mostrando " + contador + " productos.");
            lblEstado.setForeground(Color.BLACK);

            // Ajuste básico de columnas
            tablaProductos.getColumnModel().getColumn(0).setPreferredWidth(40);  // ID
            tablaProductos.getColumnModel().getColumn(1).setPreferredWidth(150); // Nombre

            con.close();
        } catch (SQLException ex) {
            lblEstado.setText("Error al cargar productos: " + ex.getMessage());
            lblEstado.setForeground(Color.RED);
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VisualizarProductos frame = new VisualizarProductos();
            frame.setVisible(true);
        });
    }
}