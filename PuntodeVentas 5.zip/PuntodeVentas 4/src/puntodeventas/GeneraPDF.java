package puntodeventas;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class GeneraPDF {

    private static final Font TITULO_FONT = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
    private static final Font SUBTITULO_FONT = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
    private static final Font NORMAL_FONT = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12); // Todo en negrita

    public static String generarPDFRegistro(String nombre, String apellido, String usuario,
                                            String contrasena, String email) {
        String nombreArchivo = "";
        try {
            // Crear nombre de archivo único
            String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            nombreArchivo = "Credenciales_" + usuario + "_" + fechaHora + ".pdf";

            Document documento = new Document();
            PdfWriter writer = PdfWriter.getInstance(documento, new FileOutputStream(nombreArchivo));
            documento.open();

            // Fondo blanco
            Rectangle pagina = documento.getPageSize();
            PdfContentByte canvas = writer.getDirectContentUnder();
            canvas.setColorFill(BaseColor.WHITE); // Fondo blanco
            canvas.rectangle(pagina.getLeft(), pagina.getBottom(), pagina.getWidth(), pagina.getHeight());
            canvas.fill();

            // Logo como fondo decorativo
            Image logo = Image.getInstance("C:\\Users\\ivone\\OneDrive\\Escritorio\\Estructura de datos\\PuntodeVentas 4\\PuntodeVentas 2\\src\\img\\FondoN.jpg");
            logo.setAbsolutePosition(
                (pagina.getWidth() - 300) / 2, // Centrado horizontal
                (pagina.getHeight() - 200) / 2 // Centrado vertical
            );
            logo.scaleAbsolute(300, 300);
            logo.setAlignment(Image.UNDERLYING);
            canvas.addImage(logo);

            // Contenido del PDF
            documento.add(new Paragraph("Comprobante de Registro", TITULO_FONT));
            documento.add(new Paragraph("Datos del usuario:", SUBTITULO_FONT));
            documento.add(new Paragraph("Nombre: " + nombre + " " + apellido, NORMAL_FONT));
            documento.add(new Paragraph("Usuario: " + usuario, NORMAL_FONT));
            documento.add(new Paragraph("Contraseña temporal: " + contrasena, NORMAL_FONT));
            documento.add(new Paragraph("Fecha registro: " + LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")), NORMAL_FONT));

            // Advertencia de seguridad
            Paragraph advertencia = new Paragraph("\nADVERTENCIA DE SEGURIDAD:", SUBTITULO_FONT);
            advertencia.setSpacingBefore(15);
            documento.add(advertencia);

            Paragraph textoAdvertencia = new Paragraph(
                "Este documento contiene información sensible. Por su seguridad:\n"
                + "- No comparta este PDF con nadie\n"
                + "- Cambie su contraseña periódicamente\n"
                + "- Elimine este archivo después de recordar sus credenciales",
                NORMAL_FONT);
            textoAdvertencia.setSpacingAfter(20);
            documento.add(textoAdvertencia);

            // Mensaje final
            Paragraph mensaje = new Paragraph("Gracias por registrarse en nuestro sistema.", NORMAL_FONT);
            mensaje.setAlignment(Element.ALIGN_CENTER);
            documento.add(mensaje);

            documento.close();

            // Enviar por correo
            EmailSender.enviarCredenciales(email, nombreArchivo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al generar PDF: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
        return nombreArchivo;
    }
}
